//(c)2010 by Texas Instruments Incorporated, All Rights Reserved.
/*----------------------------------------------------------------------------+
 |                                                                             |
 |                              Texas Instruments                              |
 |                                                                             |
 |                          MSP430 USB-Example (MSC Driver)                    |
 |                                                                             |
 +-----------------------------------------------------------------------------+
 |  Source: UsbMsc.h, File Version 1.01                                        |
 |  Description: This file contains API declarations for function to use by    |
 |               User Application.                                             |
 |  Author: Biju,MSP                                                           |
 |                                                                             |
 |  WHO          WHEN         WHAT                                             |
 |  ---          ----------   ------------------------------------------------ |
 |  RSTO         2010/10/29   Created                                          |
 +----------------------------------------------------------------------------*/
#ifndef _USB_MSCSTATE_H_
#define _USB_MSCSTATE_H_

#ifdef __cplusplus
extern "C"
{
#endif

//this file is obsolete. To delete in next version.

#ifdef __cplusplus
}
#endif
#endif  //_USB_MSCSTATE_H_

